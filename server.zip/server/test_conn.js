const mongoose = require('mongoose');
require('dotenv').config();

console.log('Testing connection to:', process.env.MONGO_URI.replace(/:([^@]+)@/, ':****@'));

mongoose.connect(process.env.MONGO_URI)
    .then(() => {
        console.log('✅ Success!');
        process.exit(0);
    })
    .catch(err => {
        console.error('❌ Failed:', err.message);
        process.exit(1);
    });
