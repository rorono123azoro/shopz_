const express = require('express');
const router = express.Router();
const { getStats, updateBanner, getBanner, getAllUsers } = require('../controllers/adminController');
const { protect, adminOnly } = require('../middleware/auth');

router.get('/stats', protect, adminOnly, getStats);
router.get('/banner', getBanner);
router.put('/banner', protect, adminOnly, updateBanner);
router.get('/users', protect, adminOnly, getAllUsers);

module.exports = router;
