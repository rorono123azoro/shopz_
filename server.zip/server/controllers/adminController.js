const User = require('../models/User');
const Product = require('../models/Product');
const Order = require('../models/Order');
const Admin = require('../models/Admin');

// GET /api/admin/stats
const getStats = async (req, res) => {
    try {
        const userCount = await User.countDocuments();
        const productCount = await Product.countDocuments();
        const orderCount = await Order.countDocuments();
        res.json({ users: userCount, products: productCount, orders: orderCount });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// PUT /api/admin/banner
const updateBanner = async (req, res) => {
    try {
        let admin = await Admin.findOne();
        if (!admin) admin = new Admin();
        admin.bannerImg = req.body.bannerImg;
        await admin.save();
        res.json(admin);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// GET /api/admin/banner
const getBanner = async (req, res) => {
    try {
        const admin = await Admin.findOne();
        res.json(admin || { bannerImg: '' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// GET /api/admin/users
const getAllUsers = async (req, res) => {
    try {
        const users = await User.find().select('-password');
        res.json(users);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

module.exports = { getStats, updateBanner, getBanner, getAllUsers };
