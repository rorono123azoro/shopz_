const Cart = require('../models/Cart');

// GET /api/cart
const getCart = async (req, res) => {
    try {
        const items = await Cart.find({ userId: req.user.id });
        res.json(items);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// POST /api/cart
const addToCart = async (req, res) => {
    try {
        const item = await Cart.create({ ...req.body, userId: req.user.id });
        res.status(201).json(item);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// DELETE /api/cart/:id
const removeFromCart = async (req, res) => {
    try {
        await Cart.findByIdAndDelete(req.params.id);
        res.json({ message: 'Item removed from cart' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// DELETE /api/cart/clear (clear all cart for user)
const clearCart = async (req, res) => {
    try {
        await Cart.deleteMany({ userId: req.user.id });
        res.json({ message: 'Cart cleared' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

module.exports = { getCart, addToCart, removeFromCart, clearCart };
