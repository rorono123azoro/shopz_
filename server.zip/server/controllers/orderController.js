const Order = require('../models/Order');
const Cart = require('../models/Cart');

// POST /api/orders (place orders from cart)
const placeOrder = async (req, res) => {
    try {
        const { name, email, mobile, address, pincode, paymentMethod, items } = req.body;
        const userId = req.user.id;
        const deliveryDate = new Date();
        deliveryDate.setDate(deliveryDate.getDate() + 5);

        const orders = await Promise.all(items.map(item =>
            Order.create({
                userId, name, email, mobile, address, pincode, paymentMethod, deliveryDate,
                title: item.title, description: item.description,
                mainImg: item.mainImg, size: item.size,
                quantity: item.quantity, price: item.price, discount: item.discount
            })
        ));

        await Cart.deleteMany({ userId });
        res.status(201).json({ message: 'Order placed successfully', orders });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// GET /api/orders/myorders
const getUserOrders = async (req, res) => {
    try {
        const orders = await Order.find({ userId: req.user.id }).sort({ createdAt: -1 });
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// GET /api/orders (admin - all orders)
const getAllOrders = async (req, res) => {
    try {
        const orders = await Order.find().populate('userId', 'username email mobile').sort({ createdAt: -1 });
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// PUT /api/orders/:id/status (admin)
const updateOrderStatus = async (req, res) => {
    try {
        const order = await Order.findByIdAndUpdate(
            req.params.id, { status: req.body.status }, { new: true }
        );
        res.json(order);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// PUT /api/orders/:id/cancel
const cancelOrder = async (req, res) => {
    try {
        const order = await Order.findByIdAndUpdate(
            req.params.id, { status: 'cancelled' }, { new: true }
        );
        res.json(order);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

module.exports = { placeOrder, getUserOrders, getAllOrders, updateOrderStatus, cancelOrder };
