const Product = require('../models/Product');

// GET /api/products
const getAllProducts = async (req, res) => {
    try {
        const { category, gender, sort, search } = req.query;
        let query = {};
        if (category) query.category = { $regex: new RegExp(`^${category}$`, 'i') };
        if (gender) query.gender = gender;
        if (search) query.title = { $regex: search, $options: 'i' };

        let products = Product.find(query);
        if (sort === 'low') products = products.sort({ price: 1 });
        else if (sort === 'high') products = products.sort({ price: -1 });
        else if (sort === 'discount') products = products.sort({ discount: -1 });

        const result = await products;
        res.json(result);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// GET /api/products/:id
const getProductById = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) return res.status(404).json({ message: 'Product not found' });
        res.json(product);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// POST /api/products (admin only)
const createProduct = async (req, res) => {
    try {
        const product = await Product.create(req.body);
        res.status(201).json(product);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

// DELETE /api/products/:id (admin only)
const deleteProduct = async (req, res) => {
    try {
        await Product.findByIdAndDelete(req.params.id);
        res.json({ message: 'Product deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

module.exports = { getAllProducts, getProductById, createProduct, deleteProduct };
