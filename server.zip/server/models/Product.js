const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    mainImg: { type: String, required: true },
    carousel: [{ type: String }],
    sizes: [{ type: String, enum: ['S', 'M', 'L', 'XL'] }],
    category: { type: String, enum: ['mobiles', 'Electronics', 'Sports-Equipment', 'Fashion', 'Groceries'], required: true },
    gender: { type: String, enum: ['Men', 'Women', 'Unisex'], default: 'Unisex' },
    price: { type: Number, required: true },
    discount: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('Product', productSchema);
