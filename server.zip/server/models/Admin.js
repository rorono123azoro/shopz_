const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema({
    bannerImg: { type: String, default: '' },
    categories: [{ type: String }]
}, { timestamps: true });

module.exports = mongoose.model('Admin', adminSchema);
